import os

server_path = "repo\\CACCC_Resource_Database\\resource_database\\server.js"
settings_file = open("settings.txt", "r")
#settings_dict has default values that are updated in settings.txt
settings_dict = {"uploadPath": "../../assets/attachments", "mongoPath": "C:/Program Files/MongoDB/Server/4.2/bin/mongod.exe", "dbPath": "../../db_files", "dontStartMongo": "false"}

#obtain all settings from settings_file and update them in settings_dict
#line format *setting name*: *value*
lines = settings_file.readlines()
for line in lines:
    if line.find(':') == -1:
        continue
    setting_tuple = line.split(':', 1)
    if settings_dict.__contains__(setting_tuple[0]):
        settings_dict[0] = setting_tuple[1]
settings_file.close()

#create cmd args string
cmd_args = ""
for kvp in settings_dict.items():
    (key, value) = kvp
    try:
        cmd_args += "-" + key
        cmd_args += " \"" + value + "\" "
    except:
        print("exception")

#run the server using node
os.system("node " + server_path + " " + cmd_args)
